<?php

namespace Drupal\custom_register\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;

class RegisterForm extends FormBase {
    
    public function getFormId() {
        return 'register_Form';
    }
    
    public function getFormPrefix($step){
    
     switch ($step) {
       case 1:
        return '<div class="my-form-wrapper">
             <ul id="progressbar">
               <li class="active" id="account"><span><strong>Basic</strong></span></li>
               <li id="personal"><span><strong>Personal</strong></span></li>
               <li id="confirm"><span><strong>Final</strong></span></li>
             </ul>
         </div>';
         break;
       case 2:
         return '<div class="my-form-wrapper">
           <ul id="progressbar">
             <li  id="account"><span><strong>Basic</strong></span></li>
             <li class="active" id="personal"><span><strong>Personal</strong></span></li>
             <li id="confirm"><span><strong>Final</strong></span></li>
         </ul>
         </div>';
         break;
       case 3:
         return '<div class="my-form-wrapper">
           <ul id="progressbar">
             <li  id="account"><span><strong>Basic</strong></span></li>
             <li id="personal"><span><strong>Personal</strong></span></li>
             <li id="confirm" class="active"><span><strong>Final</strong></span></li>
         </ul>
         </div>';
         break;
       default:
          return '';
 
 
 }
}
    
    public function custom_register_form_user_register_form_alter(array &$form, FormStateInterface $form_state) 
    {
        
        $form['description'] = [
         '#type' => 'item',
         '#title' => $this->t('A basic multistep form (page 1)'),
       ];

       $form['name'] = [
         '#type' => 'textfield',
         '#title' => $this->t('Username'),
         '#description' => $this->t('Enter your Username.'),
         '#default_value' => $form_state->getValue('name', ''),
         '#required' => TRUE,
       ];

       $form['pass'] = [
         '#type' => 'password',
         '#title' => $this->t('Password'),
         '#default_value' => $form_state->getValue('pass', ''),
         '#description' => $this->t('password'),
       ];
        
        $form_state->set(‘page_num’, 1);
        $form['actions'] = [
     '#type' => 'actions',
   ];
 
   $form['actions']['next'] = [
     '#type' => 'submit',
     '#button_type' => 'primary',
     '#value' => $this->t('Next'),
     // Custom submission handler for page 1.
     '#submit' => ['::registerFirstNextSubmit'],
     // Custom validation handler for page 1.
     //'#validate' => ['::fapiExampleMultistepFormNextValidate'],
   ];
        
             if ($form_state->has('page_num') && $form_state->get('page_num') == 2) {
             //return $this->fapiExamplePageTwo($form, $form_state);
               return $this->registerPageTwo($form, $form_state);
             }

             if ($form_state->has('page_num') && $form_state->get('page_num') == 3) {
               return $this->registerPageThree($form, $form_state);
             }   
        
    }
    
    public function registerFirstNextSubmit(array &$form, FormStateInterface $form_state) {
   $form_state
     ->set('page_values', [
       // Keep only first step values to minimize stored data.
       'name' => $form_state->getValue('name'),
       'pass' => $form_state->getValue('pass'),
      
     ])
     ->set('page_num', 2)
     // Since we have logic in our buildForm() method, we have to tell the form
     // builder to rebuild the form. Otherwise, even though we set 'page_num'
     // to 2, the AJAX-rendered form will still show page 1.
     ->setRebuild(TRUE);
 }
    
    
    public function registerPageTwo(array &$form, FormStateInterface $form_state) {
 
  
   $form['description'] = [
     '#type' => 'item',
     '#title' => $this->t('A basic multistep form (page 2)'),
   ];
 
   $form['field_fullname_value'] = [
     '#type' => 'textfield',
     '#title' => $this->t('Fullname'),
     '#required' => TRUE,
     '#default_value' => $form_state->getValue('field_fullname_value', ''),
   ];
   $form['field_birthdate_value'] = [
     '#type' => 'date',
     '#title' => $this->t('Birth date'),
     '#required' => TRUE,
     '#default_value' => $form_state->getValue('field_birthdate_value', ''),
   ];
   $form['back'] = [
     '#type' => 'submit',
     '#value' => $this->t('Back'),
     // Custom submission handler for 'Back' button.
     '#submit' => ['::registerPageTwoBack'],
     // We won't bother validating the required 'color' field, since they
     // have to come back to this page to submit anyway.
     '#limit_validation_errors' => [],
   ];
   $form['submit'] = [
     '#type' => 'submit',
     '#button_type' => 'primary',
     '#value' => $this->t('Next'),
     '#submit' => ['::registersSecondNextSubmit']
   ];
   $form['#prefix'] = $this->getFormPrefix(2);
  
 
   return $form;
 }    
  
    public function registerSecondNextSubmit(array &$form, FormStateInterface $form_state) {
   $name = $form_state->get('page_values');
   //print_r($fname);exit;
   $form_state
     ->set('page_values', [
       // Keep only first step values to minimize stored data.
       'field_fullname_value' => $form_state->getValue('field_fullname_value'),
       'field_birthdate_value' => $form_state->getValue('field_birthdate_value'),
         'name' => $name['name'],
       'pass' => $name['pass'],
       
 
     ])
     ->set('page_num', 3)
     // Since we have logic in our buildForm() method, we have to tell the form
     // builder to rebuild the form. Otherwise, even though we set 'page_num'
     // to 2, the AJAX-rendered form will still show page 1.
     ->setRebuild(TRUE);
 }
    
  public function registerPageThree(array &$form, FormStateInterface $form_state) {
 
   
   $form['description'] = [
     '#type' => 'Customer detail',
     '#title' => $this->t('A basic multistep form (page 3)'),
   ];
 
  
   $form['favorite'] = [
     '#type' => 'select_or_other_select',
  '#title' => t('Choose your favorite type'),
  '#default_value' => array('value_1'),
  '#options' => array(
    'value_1' => t('pepperoni'),
    'value_2' => t('cheese'),
    'value_3' => t('meatlovers'),
    'value_4' => t('vegetarian'),
    'value_5' => t('Hawaiian'),
  ),
  '#required' => TRUE,
  '#multiple' => FALSE,
  '#select_type' => 'select', // Defaults to 'select'.  Can also be 'radios' or 'checkboxes'.
    
   ];
   $form['back'] = [
     '#type' => 'submit',
     '#value' => $this->t('Back'),
     // Custom submission handler for 'Back' button.
     '#submit' => ['::registerPageThreeBack'],
     // We won't bother validating the required 'color' field, since they
     // have to come back to this page to submit anyway.
     '#limit_validation_errors' => [],
   ];
   $form['submit'] = [
     '#type' => 'submit',
     '#button_type' => 'primary',
     '#value' => $this->t('Submit'),
   ];
   $form['#prefix'] = $this->getFormPrefix(3);
  
 
   return $form;
 }
    
    public function submitForm(array &$form, FormStateInterface $form_state) {
   $page_values = $form_state->get('page_values');
 
   $this->messenger()->addMessage($this->t('The form has been submitted successfully', [
     '@username' => $page_values['name'],
     '@fullname' => $page_values['field_fullname_value'],
     '@birthdate' => $page_values['field_birthdate_value'],
     '@favorite' => $page_values['favorite'],
   ]));
        
        
        $fields = array(
              'name' => $page_values['name'],
              'pass' => $page_values['pass'],
              'status' => 1,
              'access' => REQUEST_TIME,
              'roles' => array(
               4 => 'customer',
                ),

        );
        $account=user_save('', $fields); 
}

    public function registerePageTwoBack(array &$form, FormStateInterface $form_state) {
   $form_state
     // Restore values for the first step.
     ->setValues($form_state->get('page_values'))
     ->set('page_num', 1)
 }
 
 public function registerPageThreeBack(array &$form, FormStateInterface $form_state) {
   $form_state
     // Restore values for the first step.
     ->setValues($form_state->get('page_values'))
     ->set('page_num', 2)
     ->setRebuild(TRUE);
 }
    
    
    
    
    
    
    
    
    
}
